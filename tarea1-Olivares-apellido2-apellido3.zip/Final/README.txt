Para compilar de una manera correcta y sin errores seguir los siguientes pasos:

Tener todos los archivos dentro de una misma carpeta, en caso de no ser así modificar codigo para poder leer el archivo servicio.txt o tickets.dat desde donde se encuentren.

Luego en la terminal de bash acceder a la carpeta y buscar el archivo o buscar el archivo donde se encuentre en caso de ser necesario.

Cuando se encuentre en la misma direción que el archivo ejecutar el siguiente codigo.

Para compilar: g++ Tarea_tickets.cpp -o Tarea -Wall
Para ejecutar: ./Tarea

La forma de ejecución usada es mediante g++, siguiendo los pasos de arriba.